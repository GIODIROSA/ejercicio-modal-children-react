import React from "react";

//componentes
import Modals from "./components/Modals";

const App = () => {
  return (
    <>
      <h2>Ejercicios Jonmircha React</h2>
      <hr />
      <Modals />
      <hr />
    </>
  );
};

export default App;
